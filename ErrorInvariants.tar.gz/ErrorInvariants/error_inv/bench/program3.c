// simple loop

// backward = forward

//int main(int x, int y) {
int main(int n) {
  int x=6;
  int y=n; 
 
  while (x < n) {  
    x = x + 1; 
    y = y + 1; 
  }
  assert (x<=10);

}
