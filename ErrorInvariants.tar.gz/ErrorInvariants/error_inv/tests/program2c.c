


int main(int input) {
  int x = 0; 
  int y = input - 42;
  if (y<0) x = 1; 
  assert(x>0);

}
