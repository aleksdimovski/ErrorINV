// simple loop

// backward = forward


void main(int n)
{
  int x = n;
	
  while (x > 0) {
    x--;
  }
	
  assert(x>=-1);
}
