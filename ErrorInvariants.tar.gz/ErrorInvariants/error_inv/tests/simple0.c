


int main() {
  int x; 
  x = [0,1];
  assert(x<=0);

}
