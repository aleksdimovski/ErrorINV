


int main(int a, int b, int x) {
  int y=0; 
  x = x+a;
  x = x+b; 
  y = y+a;
  assert(x>=1);

}
