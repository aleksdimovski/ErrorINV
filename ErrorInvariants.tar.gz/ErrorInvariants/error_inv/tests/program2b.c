


int main(int input) {
  int x = 1; 
  int y = input - 42;
  if (y<0) x = 0; 
  else x = 1; 
  assert(x>0);

}
