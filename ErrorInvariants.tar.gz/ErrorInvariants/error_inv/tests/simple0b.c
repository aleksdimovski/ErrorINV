


int main() {
  int x,y,z;
  x =2;  
  z = x+y; 
  assert(z>10);

}
