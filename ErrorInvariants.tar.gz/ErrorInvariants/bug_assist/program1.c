
 

int main() {
  int x;
  int z = x+1;
  int y=z; 
  z = z+1;

  assert(x>y);

}
