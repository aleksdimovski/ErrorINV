

int main() {

  int input1;
  int input2;

  int x = 1;
  int y = 1;
  int z=1; 
  
  if (input1>0) { 
  	x = x + 5; 
  	y = y + 6;   	
  	z = z + 4; }
  else 
  	x = 10;   	
  if (input2>0) { 
  	x = x + 6; 
  	y = y + 5;   	
  	z = z + 4; }  	 
  assert((x<10) || (y<10));

}
