


int main() {
  int input;
  int x = 1; 
  int y = input - 42;
  if (y<0) x = 0; 
  assert(x<=0);

}
